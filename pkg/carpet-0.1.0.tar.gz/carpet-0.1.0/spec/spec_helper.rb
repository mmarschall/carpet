require 'rubygems'
require 'capistrano'